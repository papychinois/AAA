﻿namespace PPE
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tab_CreationJoueur = new System.Windows.Forms.TabPage();
            this.tab_ModificationJoueur = new System.Windows.Forms.TabPage();
            this.tab_SuppressionJoueur = new System.Windows.Forms.TabPage();
            this.tab_Impression = new System.Windows.Forms.TabPage();
            this.button1_1 = new System.Windows.Forms.Button();
            this.button2_1 = new System.Windows.Forms.Button();
            this.button3_2 = new System.Windows.Forms.Button();
            this.button4_2 = new System.Windows.Forms.Button();
            this.button5_3 = new System.Windows.Forms.Button();
            this.button6_3 = new System.Windows.Forms.Button();
            this.button7_3 = new System.Windows.Forms.Button();
            this.button8_4 = new System.Windows.Forms.Button();
            this.button9_4 = new System.Windows.Forms.Button();
            this.label1_1 = new System.Windows.Forms.Label();
            this.textBox1_1 = new System.Windows.Forms.TextBox();
            this.textBox2_1 = new System.Windows.Forms.TextBox();
            this.textBox3_1 = new System.Windows.Forms.TextBox();
            this.textBox4_1 = new System.Windows.Forms.TextBox();
            this.label2_1 = new System.Windows.Forms.Label();
            this.label3_1 = new System.Windows.Forms.Label();
            this.label4_1 = new System.Windows.Forms.Label();
            this.label5_1 = new System.Windows.Forms.Label();
            this.label6_1 = new System.Windows.Forms.Label();
            this.pictureBox1_1 = new System.Windows.Forms.PictureBox();
            this.label7_1 = new System.Windows.Forms.Label();
            this.comboBox1_2 = new System.Windows.Forms.ComboBox();
            this.label1_2 = new System.Windows.Forms.Label();
            this.label2_2 = new System.Windows.Forms.Label();
            this.textBox1_2 = new System.Windows.Forms.TextBox();
            this.textBox2_2 = new System.Windows.Forms.TextBox();
            this.textBox3_2 = new System.Windows.Forms.TextBox();
            this.textBox4_2 = new System.Windows.Forms.TextBox();
            this.label3_2 = new System.Windows.Forms.Label();
            this.label4_2 = new System.Windows.Forms.Label();
            this.label5_2 = new System.Windows.Forms.Label();
            this.label6_2 = new System.Windows.Forms.Label();
            this.checkBox2_1 = new System.Windows.Forms.CheckBox();
            this.checkBox2_2 = new System.Windows.Forms.CheckBox();
            this.checkBox2_3 = new System.Windows.Forms.CheckBox();
            this.checkBox2_4 = new System.Windows.Forms.CheckBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1_3 = new System.Windows.Forms.Label();
            this.pictureBox3_1 = new System.Windows.Forms.PictureBox();
            this.label2_3 = new System.Windows.Forms.Label();
            this.label3_3 = new System.Windows.Forms.Label();
            this.comboBox4_1 = new System.Windows.Forms.ComboBox();
            this.label1_4 = new System.Windows.Forms.Label();
            this.label3_4 = new System.Windows.Forms.Label();
            this.pictureBox4_1 = new System.Windows.Forms.PictureBox();
            this.label2_4 = new System.Windows.Forms.Label();
            this.button4_3 = new System.Windows.Forms.Button();
            this.label4_4 = new System.Windows.Forms.Label();
            this.button4_4 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tab_CreationJoueur.SuspendLayout();
            this.tab_ModificationJoueur.SuspendLayout();
            this.tab_SuppressionJoueur.SuspendLayout();
            this.tab_Impression.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tab_CreationJoueur);
            this.tabControl1.Controls.Add(this.tab_ModificationJoueur);
            this.tabControl1.Controls.Add(this.tab_SuppressionJoueur);
            this.tabControl1.Controls.Add(this.tab_Impression);
            this.tabControl1.Location = new System.Drawing.Point(0, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(699, 428);
            this.tabControl1.TabIndex = 7;
            // 
            // tab_CreationJoueur
            // 
            this.tab_CreationJoueur.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.tab_CreationJoueur.Controls.Add(this.label7_1);
            this.tab_CreationJoueur.Controls.Add(this.pictureBox1_1);
            this.tab_CreationJoueur.Controls.Add(this.label6_1);
            this.tab_CreationJoueur.Controls.Add(this.label5_1);
            this.tab_CreationJoueur.Controls.Add(this.label4_1);
            this.tab_CreationJoueur.Controls.Add(this.label3_1);
            this.tab_CreationJoueur.Controls.Add(this.label2_1);
            this.tab_CreationJoueur.Controls.Add(this.textBox4_1);
            this.tab_CreationJoueur.Controls.Add(this.textBox3_1);
            this.tab_CreationJoueur.Controls.Add(this.textBox2_1);
            this.tab_CreationJoueur.Controls.Add(this.textBox1_1);
            this.tab_CreationJoueur.Controls.Add(this.label1_1);
            this.tab_CreationJoueur.Controls.Add(this.button2_1);
            this.tab_CreationJoueur.Controls.Add(this.button1_1);
            this.tab_CreationJoueur.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tab_CreationJoueur.Location = new System.Drawing.Point(4, 22);
            this.tab_CreationJoueur.Name = "tab_CreationJoueur";
            this.tab_CreationJoueur.Padding = new System.Windows.Forms.Padding(3);
            this.tab_CreationJoueur.Size = new System.Drawing.Size(691, 402);
            this.tab_CreationJoueur.TabIndex = 0;
            this.tab_CreationJoueur.Text = "Creation joueur";
            // 
            // tab_ModificationJoueur
            // 
            this.tab_ModificationJoueur.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.tab_ModificationJoueur.Controls.Add(this.checkBox2_4);
            this.tab_ModificationJoueur.Controls.Add(this.checkBox2_3);
            this.tab_ModificationJoueur.Controls.Add(this.checkBox2_2);
            this.tab_ModificationJoueur.Controls.Add(this.checkBox2_1);
            this.tab_ModificationJoueur.Controls.Add(this.label6_2);
            this.tab_ModificationJoueur.Controls.Add(this.label5_2);
            this.tab_ModificationJoueur.Controls.Add(this.label4_2);
            this.tab_ModificationJoueur.Controls.Add(this.label3_2);
            this.tab_ModificationJoueur.Controls.Add(this.textBox4_2);
            this.tab_ModificationJoueur.Controls.Add(this.textBox3_2);
            this.tab_ModificationJoueur.Controls.Add(this.textBox2_2);
            this.tab_ModificationJoueur.Controls.Add(this.textBox1_2);
            this.tab_ModificationJoueur.Controls.Add(this.label2_2);
            this.tab_ModificationJoueur.Controls.Add(this.label1_2);
            this.tab_ModificationJoueur.Controls.Add(this.comboBox1_2);
            this.tab_ModificationJoueur.Controls.Add(this.button4_2);
            this.tab_ModificationJoueur.Controls.Add(this.button3_2);
            this.tab_ModificationJoueur.Location = new System.Drawing.Point(4, 22);
            this.tab_ModificationJoueur.Name = "tab_ModificationJoueur";
            this.tab_ModificationJoueur.Padding = new System.Windows.Forms.Padding(3);
            this.tab_ModificationJoueur.Size = new System.Drawing.Size(691, 402);
            this.tab_ModificationJoueur.TabIndex = 1;
            this.tab_ModificationJoueur.Text = "Modification joueur";
            // 
            // tab_SuppressionJoueur
            // 
            this.tab_SuppressionJoueur.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.tab_SuppressionJoueur.Controls.Add(this.label3_3);
            this.tab_SuppressionJoueur.Controls.Add(this.label2_3);
            this.tab_SuppressionJoueur.Controls.Add(this.pictureBox3_1);
            this.tab_SuppressionJoueur.Controls.Add(this.label1_3);
            this.tab_SuppressionJoueur.Controls.Add(this.comboBox1);
            this.tab_SuppressionJoueur.Controls.Add(this.button7_3);
            this.tab_SuppressionJoueur.Controls.Add(this.button6_3);
            this.tab_SuppressionJoueur.Controls.Add(this.button5_3);
            this.tab_SuppressionJoueur.Location = new System.Drawing.Point(4, 22);
            this.tab_SuppressionJoueur.Name = "tab_SuppressionJoueur";
            this.tab_SuppressionJoueur.Padding = new System.Windows.Forms.Padding(3);
            this.tab_SuppressionJoueur.Size = new System.Drawing.Size(691, 402);
            this.tab_SuppressionJoueur.TabIndex = 2;
            this.tab_SuppressionJoueur.Text = "Suppression joueur";
            // 
            // tab_Impression
            // 
            this.tab_Impression.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.tab_Impression.Controls.Add(this.button4_4);
            this.tab_Impression.Controls.Add(this.label4_4);
            this.tab_Impression.Controls.Add(this.button4_3);
            this.tab_Impression.Controls.Add(this.label2_4);
            this.tab_Impression.Controls.Add(this.pictureBox4_1);
            this.tab_Impression.Controls.Add(this.label3_4);
            this.tab_Impression.Controls.Add(this.label1_4);
            this.tab_Impression.Controls.Add(this.comboBox4_1);
            this.tab_Impression.Controls.Add(this.button9_4);
            this.tab_Impression.Controls.Add(this.button8_4);
            this.tab_Impression.Location = new System.Drawing.Point(4, 22);
            this.tab_Impression.Name = "tab_Impression";
            this.tab_Impression.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Impression.Size = new System.Drawing.Size(691, 402);
            this.tab_Impression.TabIndex = 3;
            this.tab_Impression.Text = "Impression / Tag";
            // 
            // button1_1
            // 
            this.button1_1.Location = new System.Drawing.Point(482, 336);
            this.button1_1.Name = "button1_1";
            this.button1_1.Size = new System.Drawing.Size(165, 45);
            this.button1_1.TabIndex = 0;
            this.button1_1.Text = "Confirmation";
            this.button1_1.UseVisualStyleBackColor = true;
            // 
            // button2_1
            // 
            this.button2_1.Location = new System.Drawing.Point(44, 336);
            this.button2_1.Name = "button2_1";
            this.button2_1.Size = new System.Drawing.Size(165, 45);
            this.button2_1.TabIndex = 1;
            this.button2_1.Text = "Annuler";
            this.button2_1.UseVisualStyleBackColor = true;
            // 
            // button3_2
            // 
            this.button3_2.Location = new System.Drawing.Point(38, 332);
            this.button3_2.Name = "button3_2";
            this.button3_2.Size = new System.Drawing.Size(165, 45);
            this.button3_2.TabIndex = 2;
            this.button3_2.Text = "Annuler";
            this.button3_2.UseVisualStyleBackColor = true;
            // 
            // button4_2
            // 
            this.button4_2.Location = new System.Drawing.Point(490, 332);
            this.button4_2.Name = "button4_2";
            this.button4_2.Size = new System.Drawing.Size(165, 45);
            this.button4_2.TabIndex = 3;
            this.button4_2.Text = "Sauvegarde";
            this.button4_2.UseVisualStyleBackColor = true;
            // 
            // button5_3
            // 
            this.button5_3.Location = new System.Drawing.Point(32, 332);
            this.button5_3.Name = "button5_3";
            this.button5_3.Size = new System.Drawing.Size(165, 45);
            this.button5_3.TabIndex = 2;
            this.button5_3.Text = "Annuler";
            this.button5_3.UseVisualStyleBackColor = true;
            // 
            // button6_3
            // 
            this.button6_3.Location = new System.Drawing.Point(503, 332);
            this.button6_3.Name = "button6_3";
            this.button6_3.Size = new System.Drawing.Size(165, 45);
            this.button6_3.TabIndex = 3;
            this.button6_3.Text = "Suppression";
            this.button6_3.UseVisualStyleBackColor = true;
            // 
            // button7_3
            // 
            this.button7_3.Location = new System.Drawing.Point(332, 332);
            this.button7_3.Name = "button7_3";
            this.button7_3.Size = new System.Drawing.Size(165, 45);
            this.button7_3.TabIndex = 4;
            this.button7_3.Text = "Désactivation";
            this.button7_3.UseVisualStyleBackColor = true;
            // 
            // button8_4
            // 
            this.button8_4.Location = new System.Drawing.Point(41, 338);
            this.button8_4.Name = "button8_4";
            this.button8_4.Size = new System.Drawing.Size(165, 45);
            this.button8_4.TabIndex = 2;
            this.button8_4.Text = "Annuler";
            this.button8_4.UseVisualStyleBackColor = true;
            // 
            // button9_4
            // 
            this.button9_4.Location = new System.Drawing.Point(492, 338);
            this.button9_4.Name = "button9_4";
            this.button9_4.Size = new System.Drawing.Size(165, 45);
            this.button9_4.TabIndex = 3;
            this.button9_4.Text = "Imprimer";
            this.button9_4.UseVisualStyleBackColor = true;
            // 
            // label1_1
            // 
            this.label1_1.AutoSize = true;
            this.label1_1.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label1_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1_1.ForeColor = System.Drawing.Color.White;
            this.label1_1.Location = new System.Drawing.Point(23, 31);
            this.label1_1.Name = "label1_1";
            this.label1_1.Size = new System.Drawing.Size(209, 16);
            this.label1_1.TabIndex = 2;
            this.label1_1.Text = "Entrer information du joueur : ";
            this.label1_1.Click += new System.EventHandler(this.label1_1_Click);
            // 
            // textBox1_1
            // 
            this.textBox1_1.Location = new System.Drawing.Point(153, 91);
            this.textBox1_1.Name = "textBox1_1";
            this.textBox1_1.Size = new System.Drawing.Size(181, 21);
            this.textBox1_1.TabIndex = 3;
            // 
            // textBox2_1
            // 
            this.textBox2_1.Location = new System.Drawing.Point(153, 134);
            this.textBox2_1.Name = "textBox2_1";
            this.textBox2_1.Size = new System.Drawing.Size(181, 21);
            this.textBox2_1.TabIndex = 4;
            // 
            // textBox3_1
            // 
            this.textBox3_1.Location = new System.Drawing.Point(153, 179);
            this.textBox3_1.Name = "textBox3_1";
            this.textBox3_1.Size = new System.Drawing.Size(181, 21);
            this.textBox3_1.TabIndex = 5;
            // 
            // textBox4_1
            // 
            this.textBox4_1.Location = new System.Drawing.Point(153, 223);
            this.textBox4_1.Name = "textBox4_1";
            this.textBox4_1.Size = new System.Drawing.Size(181, 21);
            this.textBox4_1.TabIndex = 6;
            // 
            // label2_1
            // 
            this.label2_1.AutoSize = true;
            this.label2_1.ForeColor = System.Drawing.Color.White;
            this.label2_1.Location = new System.Drawing.Point(84, 94);
            this.label2_1.Name = "label2_1";
            this.label2_1.Size = new System.Drawing.Size(43, 16);
            this.label2_1.TabIndex = 7;
            this.label2_1.Text = "Nom :";
            // 
            // label3_1
            // 
            this.label3_1.AutoSize = true;
            this.label3_1.ForeColor = System.Drawing.Color.White;
            this.label3_1.Location = new System.Drawing.Point(95, 137);
            this.label3_1.Name = "label3_1";
            this.label3_1.Size = new System.Drawing.Size(32, 16);
            this.label3_1.TabIndex = 8;
            this.label3_1.Text = ". . . : ";
            // 
            // label4_1
            // 
            this.label4_1.AutoSize = true;
            this.label4_1.ForeColor = System.Drawing.Color.White;
            this.label4_1.Location = new System.Drawing.Point(95, 182);
            this.label4_1.Name = "label4_1";
            this.label4_1.Size = new System.Drawing.Size(32, 16);
            this.label4_1.TabIndex = 9;
            this.label4_1.Text = ". . . : ";
            // 
            // label5_1
            // 
            this.label5_1.AutoSize = true;
            this.label5_1.ForeColor = System.Drawing.Color.White;
            this.label5_1.Location = new System.Drawing.Point(95, 226);
            this.label5_1.Name = "label5_1";
            this.label5_1.Size = new System.Drawing.Size(32, 16);
            this.label5_1.TabIndex = 10;
            this.label5_1.Text = ". . . : ";
            // 
            // label6_1
            // 
            this.label6_1.AutoSize = true;
            this.label6_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6_1.ForeColor = System.Drawing.Color.White;
            this.label6_1.Location = new System.Drawing.Point(521, 31);
            this.label6_1.Name = "label6_1";
            this.label6_1.Size = new System.Drawing.Size(78, 16);
            this.label6_1.TabIndex = 11;
            this.label6_1.Text = "Validation";
            // 
            // pictureBox1_1
            // 
            this.pictureBox1_1.Location = new System.Drawing.Point(482, 80);
            this.pictureBox1_1.Name = "pictureBox1_1";
            this.pictureBox1_1.Size = new System.Drawing.Size(153, 120);
            this.pictureBox1_1.TabIndex = 12;
            this.pictureBox1_1.TabStop = false;
            // 
            // label7_1
            // 
            this.label7_1.AutoSize = true;
            this.label7_1.ForeColor = System.Drawing.Color.White;
            this.label7_1.Location = new System.Drawing.Point(479, 223);
            this.label7_1.Name = "label7_1";
            this.label7_1.Size = new System.Drawing.Size(74, 16);
            this.label7_1.TabIndex = 13;
            this.label7_1.Text = "Message : ";
            // 
            // comboBox1_2
            // 
            this.comboBox1_2.FormattingEnabled = true;
            this.comboBox1_2.Location = new System.Drawing.Point(109, 21);
            this.comboBox1_2.Name = "comboBox1_2";
            this.comboBox1_2.Size = new System.Drawing.Size(163, 21);
            this.comboBox1_2.TabIndex = 4;
            // 
            // label1_2
            // 
            this.label1_2.AutoSize = true;
            this.label1_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1_2.ForeColor = System.Drawing.Color.White;
            this.label1_2.Location = new System.Drawing.Point(28, 22);
            this.label1_2.Name = "label1_2";
            this.label1_2.Size = new System.Drawing.Size(75, 16);
            this.label1_2.TabIndex = 5;
            this.label1_2.Text = "Joueurs : ";
            this.label1_2.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2_2
            // 
            this.label2_2.AutoSize = true;
            this.label2_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2_2.ForeColor = System.Drawing.Color.White;
            this.label2_2.Location = new System.Drawing.Point(28, 65);
            this.label2_2.Name = "label2_2";
            this.label2_2.Size = new System.Drawing.Size(96, 16);
            this.label2_2.TabIndex = 6;
            this.label2_2.Text = "Information : ";
            // 
            // textBox1_2
            // 
            this.textBox1_2.Location = new System.Drawing.Point(109, 104);
            this.textBox1_2.Name = "textBox1_2";
            this.textBox1_2.Size = new System.Drawing.Size(163, 20);
            this.textBox1_2.TabIndex = 7;
            // 
            // textBox2_2
            // 
            this.textBox2_2.Location = new System.Drawing.Point(109, 153);
            this.textBox2_2.Name = "textBox2_2";
            this.textBox2_2.Size = new System.Drawing.Size(163, 20);
            this.textBox2_2.TabIndex = 8;
            // 
            // textBox3_2
            // 
            this.textBox3_2.Location = new System.Drawing.Point(109, 201);
            this.textBox3_2.Name = "textBox3_2";
            this.textBox3_2.Size = new System.Drawing.Size(163, 20);
            this.textBox3_2.TabIndex = 9;
            // 
            // textBox4_2
            // 
            this.textBox4_2.Location = new System.Drawing.Point(109, 245);
            this.textBox4_2.Name = "textBox4_2";
            this.textBox4_2.Size = new System.Drawing.Size(163, 20);
            this.textBox4_2.TabIndex = 10;
            // 
            // label3_2
            // 
            this.label3_2.AutoSize = true;
            this.label3_2.ForeColor = System.Drawing.Color.White;
            this.label3_2.Location = new System.Drawing.Point(60, 107);
            this.label3_2.Name = "label3_2";
            this.label3_2.Size = new System.Drawing.Size(38, 13);
            this.label3_2.TabIndex = 11;
            this.label3_2.Text = "Nom : ";
            // 
            // label4_2
            // 
            this.label4_2.AutoSize = true;
            this.label4_2.ForeColor = System.Drawing.Color.White;
            this.label4_2.Location = new System.Drawing.Point(64, 158);
            this.label4_2.Name = "label4_2";
            this.label4_2.Size = new System.Drawing.Size(31, 13);
            this.label4_2.TabIndex = 12;
            this.label4_2.Text = ". . . : ";
            // 
            // label5_2
            // 
            this.label5_2.AutoSize = true;
            this.label5_2.ForeColor = System.Drawing.Color.White;
            this.label5_2.Location = new System.Drawing.Point(64, 205);
            this.label5_2.Name = "label5_2";
            this.label5_2.Size = new System.Drawing.Size(31, 13);
            this.label5_2.TabIndex = 13;
            this.label5_2.Text = ". . . : ";
            // 
            // label6_2
            // 
            this.label6_2.AutoSize = true;
            this.label6_2.ForeColor = System.Drawing.Color.White;
            this.label6_2.Location = new System.Drawing.Point(64, 249);
            this.label6_2.Name = "label6_2";
            this.label6_2.Size = new System.Drawing.Size(31, 13);
            this.label6_2.TabIndex = 14;
            this.label6_2.Text = ". . . : ";
            // 
            // checkBox2_1
            // 
            this.checkBox2_1.AutoSize = true;
            this.checkBox2_1.ForeColor = System.Drawing.Color.White;
            this.checkBox2_1.Location = new System.Drawing.Point(295, 107);
            this.checkBox2_1.Name = "checkBox2_1";
            this.checkBox2_1.Size = new System.Drawing.Size(84, 17);
            this.checkBox2_1.TabIndex = 15;
            this.checkBox2_1.Text = "Confirmation";
            this.checkBox2_1.UseVisualStyleBackColor = true;
            // 
            // checkBox2_2
            // 
            this.checkBox2_2.AutoSize = true;
            this.checkBox2_2.ForeColor = System.Drawing.Color.White;
            this.checkBox2_2.Location = new System.Drawing.Point(295, 155);
            this.checkBox2_2.Name = "checkBox2_2";
            this.checkBox2_2.Size = new System.Drawing.Size(84, 17);
            this.checkBox2_2.TabIndex = 17;
            this.checkBox2_2.Text = "Confirmation";
            this.checkBox2_2.UseVisualStyleBackColor = true;
            // 
            // checkBox2_3
            // 
            this.checkBox2_3.AutoSize = true;
            this.checkBox2_3.ForeColor = System.Drawing.Color.White;
            this.checkBox2_3.Location = new System.Drawing.Point(295, 203);
            this.checkBox2_3.Name = "checkBox2_3";
            this.checkBox2_3.Size = new System.Drawing.Size(84, 17);
            this.checkBox2_3.TabIndex = 19;
            this.checkBox2_3.Text = "Confirmation";
            this.checkBox2_3.UseVisualStyleBackColor = true;
            // 
            // checkBox2_4
            // 
            this.checkBox2_4.AutoSize = true;
            this.checkBox2_4.ForeColor = System.Drawing.Color.White;
            this.checkBox2_4.Location = new System.Drawing.Point(295, 247);
            this.checkBox2_4.Name = "checkBox2_4";
            this.checkBox2_4.Size = new System.Drawing.Size(84, 17);
            this.checkBox2_4.TabIndex = 21;
            this.checkBox2_4.Text = "Confirmation";
            this.checkBox2_4.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(129, 44);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(152, 21);
            this.comboBox1.TabIndex = 5;
            // 
            // label1_3
            // 
            this.label1_3.AutoSize = true;
            this.label1_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1_3.ForeColor = System.Drawing.Color.White;
            this.label1_3.Location = new System.Drawing.Point(48, 45);
            this.label1_3.Name = "label1_3";
            this.label1_3.Size = new System.Drawing.Size(75, 16);
            this.label1_3.TabIndex = 6;
            this.label1_3.Text = "Joueurs : ";
            // 
            // pictureBox3_1
            // 
            this.pictureBox3_1.Location = new System.Drawing.Point(436, 90);
            this.pictureBox3_1.Name = "pictureBox3_1";
            this.pictureBox3_1.Size = new System.Drawing.Size(100, 86);
            this.pictureBox3_1.TabIndex = 7;
            this.pictureBox3_1.TabStop = false;
            // 
            // label2_3
            // 
            this.label2_3.AutoSize = true;
            this.label2_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2_3.ForeColor = System.Drawing.Color.White;
            this.label2_3.Location = new System.Drawing.Point(436, 51);
            this.label2_3.Name = "label2_3";
            this.label2_3.Size = new System.Drawing.Size(94, 16);
            this.label2_3.TabIndex = 8;
            this.label2_3.Text = "Confirmation";
            // 
            // label3_3
            // 
            this.label3_3.AutoSize = true;
            this.label3_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3_3.ForeColor = System.Drawing.Color.White;
            this.label3_3.Location = new System.Drawing.Point(436, 201);
            this.label3_3.Name = "label3_3";
            this.label3_3.Size = new System.Drawing.Size(69, 13);
            this.label3_3.TabIndex = 9;
            this.label3_3.Text = "Message : ";
            // 
            // comboBox4_1
            // 
            this.comboBox4_1.FormattingEnabled = true;
            this.comboBox4_1.Location = new System.Drawing.Point(111, 24);
            this.comboBox4_1.Name = "comboBox4_1";
            this.comboBox4_1.Size = new System.Drawing.Size(151, 21);
            this.comboBox4_1.TabIndex = 4;
            // 
            // label1_4
            // 
            this.label1_4.AutoSize = true;
            this.label1_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1_4.ForeColor = System.Drawing.Color.White;
            this.label1_4.Location = new System.Drawing.Point(38, 25);
            this.label1_4.Name = "label1_4";
            this.label1_4.Size = new System.Drawing.Size(67, 16);
            this.label1_4.TabIndex = 5;
            this.label1_4.Text = "Joueur : ";
            // 
            // label3_4
            // 
            this.label3_4.AutoSize = true;
            this.label3_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3_4.ForeColor = System.Drawing.Color.White;
            this.label3_4.Location = new System.Drawing.Point(499, 29);
            this.label3_4.Name = "label3_4";
            this.label3_4.Size = new System.Drawing.Size(57, 16);
            this.label3_4.TabIndex = 6;
            this.label3_4.Text = "Aperçu";
            // 
            // pictureBox4_1
            // 
            this.pictureBox4_1.Location = new System.Drawing.Point(430, 69);
            this.pictureBox4_1.Name = "pictureBox4_1";
            this.pictureBox4_1.Size = new System.Drawing.Size(202, 149);
            this.pictureBox4_1.TabIndex = 7;
            this.pictureBox4_1.TabStop = false;
            // 
            // label2_4
            // 
            this.label2_4.AutoSize = true;
            this.label2_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2_4.ForeColor = System.Drawing.Color.White;
            this.label2_4.Location = new System.Drawing.Point(427, 231);
            this.label2_4.Name = "label2_4";
            this.label2_4.Size = new System.Drawing.Size(64, 16);
            this.label2_4.TabIndex = 8;
            this.label2_4.Text = "Pseudo : ";
            // 
            // button4_3
            // 
            this.button4_3.Location = new System.Drawing.Point(492, 274);
            this.button4_3.Name = "button4_3";
            this.button4_3.Size = new System.Drawing.Size(165, 45);
            this.button4_3.TabIndex = 9;
            this.button4_3.Text = "Sauvegarder";
            this.button4_3.UseVisualStyleBackColor = true;
            // 
            // label4_4
            // 
            this.label4_4.AutoSize = true;
            this.label4_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4_4.ForeColor = System.Drawing.Color.White;
            this.label4_4.Location = new System.Drawing.Point(38, 82);
            this.label4_4.Name = "label4_4";
            this.label4_4.Size = new System.Drawing.Size(67, 16);
            this.label4_4.TabIndex = 10;
            this.label4_4.Text = "Fichier : ";
            // 
            // button4_4
            // 
            this.button4_4.Location = new System.Drawing.Point(111, 80);
            this.button4_4.Name = "button4_4";
            this.button4_4.Size = new System.Drawing.Size(79, 21);
            this.button4_4.TabIndex = 11;
            this.button4_4.Text = "Parcourir";
            this.button4_4.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.ClientSize = new System.Drawing.Size(697, 428);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Gestion des joueurs";
            this.tabControl1.ResumeLayout(false);
            this.tab_CreationJoueur.ResumeLayout(false);
            this.tab_CreationJoueur.PerformLayout();
            this.tab_ModificationJoueur.ResumeLayout(false);
            this.tab_ModificationJoueur.PerformLayout();
            this.tab_SuppressionJoueur.ResumeLayout(false);
            this.tab_SuppressionJoueur.PerformLayout();
            this.tab_Impression.ResumeLayout(false);
            this.tab_Impression.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tab_CreationJoueur;
        private System.Windows.Forms.Label label7_1;
        private System.Windows.Forms.PictureBox pictureBox1_1;
        private System.Windows.Forms.Label label6_1;
        private System.Windows.Forms.Label label5_1;
        private System.Windows.Forms.Label label4_1;
        private System.Windows.Forms.Label label3_1;
        private System.Windows.Forms.Label label2_1;
        private System.Windows.Forms.TextBox textBox4_1;
        private System.Windows.Forms.TextBox textBox3_1;
        private System.Windows.Forms.TextBox textBox2_1;
        private System.Windows.Forms.TextBox textBox1_1;
        private System.Windows.Forms.Label label1_1;
        private System.Windows.Forms.Button button2_1;
        private System.Windows.Forms.Button button1_1;
        private System.Windows.Forms.TabPage tab_ModificationJoueur;
        private System.Windows.Forms.Button button4_2;
        private System.Windows.Forms.Button button3_2;
        private System.Windows.Forms.TabPage tab_SuppressionJoueur;
        private System.Windows.Forms.Button button7_3;
        private System.Windows.Forms.Button button6_3;
        private System.Windows.Forms.Button button5_3;
        private System.Windows.Forms.TabPage tab_Impression;
        private System.Windows.Forms.Button button9_4;
        private System.Windows.Forms.Button button8_4;
        private System.Windows.Forms.Label label1_2;
        private System.Windows.Forms.ComboBox comboBox1_2;
        private System.Windows.Forms.CheckBox checkBox2_4;
        private System.Windows.Forms.CheckBox checkBox2_3;
        private System.Windows.Forms.CheckBox checkBox2_2;
        private System.Windows.Forms.CheckBox checkBox2_1;
        private System.Windows.Forms.Label label6_2;
        private System.Windows.Forms.Label label5_2;
        private System.Windows.Forms.Label label4_2;
        private System.Windows.Forms.Label label3_2;
        private System.Windows.Forms.TextBox textBox4_2;
        private System.Windows.Forms.TextBox textBox3_2;
        private System.Windows.Forms.TextBox textBox2_2;
        private System.Windows.Forms.TextBox textBox1_2;
        private System.Windows.Forms.Label label2_2;
        private System.Windows.Forms.Label label3_3;
        private System.Windows.Forms.Label label2_3;
        private System.Windows.Forms.PictureBox pictureBox3_1;
        private System.Windows.Forms.Label label1_3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button4_4;
        private System.Windows.Forms.Label label4_4;
        private System.Windows.Forms.Button button4_3;
        private System.Windows.Forms.Label label2_4;
        private System.Windows.Forms.PictureBox pictureBox4_1;
        private System.Windows.Forms.Label label3_4;
        private System.Windows.Forms.Label label1_4;
        private System.Windows.Forms.ComboBox comboBox4_1;
    }
}

